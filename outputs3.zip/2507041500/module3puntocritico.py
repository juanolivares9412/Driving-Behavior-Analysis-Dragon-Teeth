import xml.etree.ElementTree as ET
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# --- Longitudes de los carriles (extraídas de tu net.net.xml) ---
# Este diccionario contiene las longitudes de cada carril, así ya no se lee del archivo .net.xml
# Se ha actualizado con las longitudes exactas de net.net.xml para evitar advertencias.
lane_lengths_map = {
    # Carriles internos (junctions) y otros de la red
    ':69.65_0_0': 0.30,
    ':69.65_0_1': 0.30,
    ':70.69_0_0': 0.30,
    ':70.69_0_1': 0.30,
    ':71.70_0_0': 0.30,
    ':71.70_0_1': 0.30,
    ':72.71_0_0': 0.30,
    ':72.71_0_1': 0.30,
    ':73.72_0_0': 0.30,
    ':73.72_0_1': 0.30,
    ':81.80_0_0': 1.99,
    ':81.80_0_1': 1.99,
    ':81.80_0_2': 1.99,
    ':82.81_0_0': 0.10,
    ':82.81_0_1': 0.10,
    ':82.81_0_2': 0.10,
    ':83.82_0_0': 0.30,
    ':83.82_0_1': 0.30,
    ':83.82_0_2': 0.30,
    ':J0_0_0': 0.10,
    ':J0_0_1': 0.10,
    ':J2_0_0': 1.56,
    ':J7_0_0': 4.89,
    ':cluster79#1_79.73_80.79_0_0': 56.85,
    ':cluster79#1_79.73_80.79_0_1': 56.85,
    ':cluster79#1_79.73_80.79_0_2': 56.85,
    ':cluster83#1_84.83_0_0': 59.79,
    ':cluster83#1_84.83_0_1': 59.79,
    ':clusterJ3_J8_0_0': 8.21,
    ':clusterJ3_J8_1_0': 10.71,
    ':clusterJ3_J8_1_1': 10.71,
    ':clusterJ3_J8_1_2': 10.71,
    ':clusterJ6_J9_0_0': 8.76,
    ':clusterJ6_J9_1_0': 8.93,
    ':clusterJ6_J9_1_1': 8.93,
    ':clusterJ6_J9_1_2': 8.93,

    '-65_0': 541.91,
    '-65_1': 541.91,
    '-65.541_0': 452.35,
    '-65.541_1': 452.35,
    '-69_0': 208.46,
    '-69_1': 208.46,
    '-70_0': 170.07,
    '-70_1': 170.07,
    '-71_0': 400.99,
    '-71_1': 400.99,
    '-72_0': 789.26,
    '-72_1': 789.26,
    '-73_0': 748.80,
    '-73_1': 748.80,
    '-74_0': 59.79,
    '-74_1': 59.79,
    '-75_0': 49.33,
    '-75_1': 49.33,
    '-76_0': 400.99,
    '-76_1': 400.99,
    '-77_0': 170.07,
    '-77_1': 170.07,
    '-78_0': 208.46,
    '-78_1': 208.46,
    '-79_0': 541.91,
    '-79_1': 541.91,
    '-80_0': 165.58,
    '-80_1': 165.58,
    '-80_2': 165.58,
    '-81_0': 1.99,
    '-81_1': 1.99,
    '-81_2': 1.99,
    '-82_0': 0.10,
    '-82_1': 0.10,
    '-82_2': 0.10,
    '-82.18_0': 82.18,
    '-82.18_1': 82.18,
    '-83_0': 0.30,
    '-83_1': 0.30,
    '-83_2': 0.30,
    '-84_0': 630.14,
    '-84_1': 630.14,
    '-85_0': 8.21,
    '-85_1': 10.71,
    '-85_2': 10.71,
    '-85_3': 10.71,
    '-86_0': 8.76,
    '-86_1': 8.93,
    '-86_2': 8.93,
    '-86_3': 8.93,
    'E0_0': 748.80,
    'E0_1': 748.80,
    'E1_0': 400.99,
    'E1_1': 400.99,
    'E2_0': 170.07,
    'E2_1': 170.07,
    'E3_0': 208.46,
    'E3_1': 208.46,
    'E4_0': 541.91,
    'E4_1': 541.91,

    # Carriles con convención de nombres que pueden aparecer en FCD pero no tan obvios en net.net.xml directamente.
    # Si '-83#0_1' aparece en tu FCD, usaremos el valor de su carril equivalente de 0.30m.
    '-83#0_1': 0.30,
    # Para '-80.130_1', si no es un error tipográfico, asumimos que se refiere a '-80_1' que es 165.58m.
    '-80.130_1': 165.58
}

# --- Función principal de análisis de FCD (con filtrado de segmentos) ---
def analyze_sumo_fcd(xml_file_path, target_vehicle_id="0", segments_of_interest=None):
    print(f"DEBUG: Iniciando análisis FCD para vehículo '{target_vehicle_id}' en '{xml_file_path}'")

    lane_lengths = lane_lengths_map # Usamos el diccionario hardcodeado

    try:
        tree = ET.parse(xml_file_path)
        root = tree.getroot()

        if root.tag not in ['fcd-output', 'fcd-export']:
            print(f"Advertencia: La etiqueta raíz del XML FCD es '{root.tag}', se esperaba 'fcd-output' o 'fcd-export'. Intentando encontrar la correcta.")
            fcd_root = None
            for element in root:
                if element.tag in ['fcd-output', 'fcd-export']:
                    fcd_root = element
                    break
            if fcd_root:
                root = fcd_root
            else:
                print("Error: No se encontró la etiqueta <fcd-output> ni <fcd-export> dentro del XML FCD. Verifique el formato.")
                return None, None

    except FileNotFoundError:
        print(f"Error: El archivo FCD no se encontró en la ruta: {xml_file_path}")
        return None, None
    except ET.ParseError as e:
        print(f"Error al analizar el archivo FCD XML: {e}. Asegúrate de que '{xml_file_path}' es un XML válido y completo.")
        return None, None


    data = []
    accumulated_distance_in_segment = 0.0
    last_lane_id_in_segment = None
    last_pos_in_segment = None

    is_in_target_segment_area = False

    timestep_count = 0
    vehicle_found_in_any_timestep = False

    for timestep in root.findall('timestep'):
        timestep_count += 1
        current_time = float(timestep.get('time'))

        for vehicle in timestep.findall('vehicle'):
            vehicle_id_in_xml = vehicle.get('id')
            if vehicle_id_in_xml == target_vehicle_id:
                speed = float(vehicle.get('speed'))
                current_pos = float(vehicle.get('pos'))
                current_lane = vehicle.get('lane')

                # --- FILTRADO POR SEGMENTOS DE INTERÉS ---
                current_lane_is_in_target_segment = False
                if segments_of_interest:
                    for seg_num in segments_of_interest:
                        # Considerar variantes de nombres de carriles
                        if f"{seg_num}" in current_lane or f"-{seg_num}" in current_lane or f":cluster{seg_num}" in current_lane:
                            current_lane_is_in_target_segment = True
                            break
                else: # Si no se especifican segmentos, se procesan todos
                    current_lane_is_in_target_segment = True

                if current_lane_is_in_target_segment:
                    if not is_in_target_segment_area:
                        # El vehículo acaba de entrar en el área de interés.
                        # Reseteamos la distancia acumulada para que empiece desde 0 en el inicio de la zona.
                        # Esto es clave para que la distancia "acumulada" sea relativa a la zona de conflicto.
                        accumulated_distance_in_segment = current_pos
                        last_pos_in_segment = current_pos
                        last_lane_id_in_segment = current_lane
                        is_in_target_segment_area = True
                    else:
                        if current_lane == last_lane_id_in_segment:
                            accumulated_distance_in_segment += (current_pos - last_pos_in_segment)
                        else:
                            if last_lane_id_in_segment in lane_lengths:
                                remaining_in_last_lane = lane_lengths[last_lane_id_in_segment] - last_pos_in_segment
                                accumulated_distance_in_segment += remaining_in_last_lane
                            else:
                                print(f"Advertencia: Longitud del carril '{last_lane_id_in_segment}' no encontrada en el diccionario de longitudes. La distancia acumulada puede ser inexacta.")

                            accumulated_distance_in_segment += current_pos

                        last_pos_in_segment = current_pos
                        last_lane_id_in_segment = current_lane

                    data.append({
                        'time': current_time,
                        'speed': speed,
                        'pos': current_pos,
                        'lane': current_lane,
                        'accumulated_distance': accumulated_distance_in_segment
                    })
                else:
                    # El vehículo está fuera del área de interés, reseteamos las variables de seguimiento
                    is_in_target_segment_area = False
                    last_pos_in_segment = None
                    last_lane_id_in_segment = None

                vehicle_found_in_any_timestep = True
                break

    print(f"DEBUG: Total de timesteps procesados: {timestep_count}")
    print(f"DEBUG: ¿Vehículo '{target_vehicle_id}' encontrado en algún timestep? {vehicle_found_in_any_timestep}")
    print(f"DEBUG: Número final de puntos de datos en 'data': {len(data)}")


    if not data:
        print(f"No se encontraron datos para el vehículo '{target_vehicle_id}' en los segmentos especificados en el archivo. La lista 'data' está vacía.")
        return None, None

    df = pd.DataFrame(data)

    # Asegurarse de que la distancia acumulada comience desde 0 si el primer punto no lo hizo
    if not df.empty and df['accumulated_distance'].iloc[0] != 0:
        offset = df['accumulated_distance'].iloc[0]
        df['accumulated_distance'] = df['accumulated_distance'] - offset


    # --- Cálculo de Aceleración y Desaceleración ---
    df['time_diff'] = df['time'].diff()
    df['speed_diff'] = df['speed'].diff()
    df['acceleration'] = df['speed_diff'] / df['time_diff']

    df['acceleration'] = df['acceleration'].replace([np.inf, -np.inf], np.nan).fillna(0)

    df['acceleration_positive'] = df['acceleration'].apply(lambda x: x if x > 0 else 0)
    df['deceleration_negative'] = df['acceleration'].apply(lambda x: x if x < 0 else 0)

    # --- Análisis Estadístico ---
    avg_speed = df['speed'].mean()
    std_speed = df['speed'].std()
    max_speed = df['speed'].max()
    min_speed = df['speed'].min()

    # Calcular la aceleración promedio solo para valores positivos y que no sean NaN
    avg_acceleration_val = df['acceleration_positive'][df['acceleration_positive'] > 0].mean()
    avg_acceleration = avg_acceleration_val if pd.notna(avg_acceleration_val) else 0

    # Calcular la desaceleración promedio solo para valores negativos y que no sean NaN
    avg_deceleration_val = df['deceleration_negative'][df['deceleration_negative'] < 0].mean()
    avg_deceleration = avg_deceleration_val if pd.notna(avg_deceleration_val) else 0

    total_distance_covered = df['accumulated_distance'].iloc[-1] if not df.empty else 0.0

    stats = {
        'Velocidad Promedio (m/s)': avg_speed,
        'Desviación Estándar de Velocidad (m/s)': std_speed,
        'Velocidad Máxima (m/s)': max_speed,
        'Velocidad Mínima (m/s)': min_speed,
        'Aceleración Promedio (m/s^2, solo acelerando)': avg_acceleration,
        'Desaceleración Promedio (m/s^2, solo frenando)': avg_deceleration,
        'Distancia Acumulada Total en Segmentos Filtrados (m)': total_distance_covered
    }

    return df, stats

# --- Ejecución del Análisis para los tres escenarios ---
# ******************************************************************************
# RUTA BASE ACTUALIZADA A LA NUEVA UBICACIÓN
# ******************************************************************************
base_path = 'C:/Users/danie/Desktop/PC/maestría/2do semestre/02.- Modelado y simulación/marcas dientes de dragon/resultados prueba diente dragon/resultados prueba diente dragon/0407250300/'

# Nombres de los archivos de resultados para cada escenario
scenario_files = {
    "RL": "RL.xml",  # Asumiendo que ahora se llaman RL.xml, DD.xml, SM.xml
    "DD": "DD.xml",
    "SM": "SM.xml"
}

# Segmentos de interés donde está el punto de conflicto
target_segments_conflict_area = ['71', '72', '73', '79', '80', '81', '82', '83']


all_processed_data = {}
all_statistics = {}

for scenario_name, file_name in scenario_files.items():
    full_file_path = f"{base_path}{file_name}"
    print(f"\n--- Procesando escenario: {scenario_name} ({full_file_path}) ---")

    processed_df, stats = analyze_sumo_fcd(full_file_path, target_vehicle_id="0",
                                           segments_of_interest=target_segments_conflict_area)

    if processed_df is not None:
        all_processed_data[scenario_name] = processed_df
        all_statistics[scenario_name] = stats
    else:
        print(f"No se pudo procesar el escenario {scenario_name}. Saltando gráficas y estadísticas para este.")


# --- Generación de Gráficas Individuales por Escenario ---

print("\n--- Generando Gráficas Individuales por Escenario ---")

for scenario_name, df in all_processed_data.items():
    # Gráfica de Velocidad vs. Distancia Acumulada para este escenario
    plt.figure(figsize=(12, 6))
    plt.plot(df['accumulated_distance'], df['speed'], color='blue', label=f'Velocidad {scenario_name}')
    plt.title(f'Velocidad vs. Distancia Acumulada - Escenario: {scenario_name} (Vehículo "0")')
    plt.xlabel('Distancia Acumulada en Zona de Conflicto (m)')
    plt.ylabel('Velocidad (m/s)')
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()

    # Gráfica de Aceleración vs. Distancia Acumulada para este escenario
    plt.figure(figsize=(12, 6))
    plt.plot(df['accumulated_distance'], df['acceleration'], color='red', label=f'Aceleración {scenario_name}')
    plt.axhline(0, color='gray', linestyle='--', linewidth=0.8, label='Aceleración Cero')
    plt.title(f'Aceleración vs. Distancia Acumulada - Escenario: {scenario_name} (Vehículo "0")')
    plt.xlabel('Distancia Acumulada en Zona de Conflicto (m)')
    plt.ylabel('Aceleración (m/s²)')
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()

# --- Imprimir estadísticas detalladas por cada escenario ---
print("\n--- Estadísticas Detalladas por Escenario en Zona de Conflicto ---")
for scenario_name, stats in all_statistics.items():
    print(f"\n***** Escenario: {scenario_name} *****")
    for key, value in stats.items():
        print(f"{key}: {value:.2f}")