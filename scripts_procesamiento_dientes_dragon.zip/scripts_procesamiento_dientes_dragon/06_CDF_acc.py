import pandas as pd
from scipy.stats import ttest_rel, wilcoxon
from numpy import mean, std
import math
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
file_path = 'Speed_Dataset_Final.csv'
data = pd.read_csv(file_path)

# Cumulative Distribution Function (CDF)
plt.figure(figsize=(10, 5))
# Dragon Teeth
sns.ecdfplot(data['acc_D_d'], color='green', linestyle='-', linewidth=2, label='Dragon Teeth')
# Transverse Bars
sns.ecdfplot(data['acc_T_d'], color='blue', linestyle='--', linewidth=2, label='Transverse Bars')
# No Making
sns.ecdfplot(data['acc_N_d'], color='red', linestyle=(':'), linewidth=2, label='No Marking')

# Titles and Labels
plt.title('CDFs')
plt.xlabel('Mean Acceleration (m/s^2)')
plt.ylabel('Cumulative Probability')
plt.legend()
plt.grid(True)
plt.xlim(0.5, 3)  # Set x-axis limits to 40-120 km/h
plt.tight_layout()

# Save in different formats
plt.savefig('CDF_acc.pdf', format='pdf')  # Vector format

# Show plot
plt.show()

