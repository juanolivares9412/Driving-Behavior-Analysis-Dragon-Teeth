import xml.etree.ElementTree as ET
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
import openpyxl
from openpyxl.drawing.image import Image as ExcelImage
import io
from PIL import Image as PILImage
from openpyxl.styles import Font
from matplotlib.cm import get_cmap

# --- 1. CONFIGURACIÓN PRINCIPAL ---
BASE_RESULTS_FOLDER = r"C:\Users\danie\Desktop\PC\maestría\2do semestre\02.- Modelado y simulación\marcas dientes de dragon\resultados prueba diente dragon\resultados prueba diente dragon"
OUTPUT_FOLDER = r"C:\Users\danie\Desktop\PC\maestría\2do semestre\02.- Modelado y simulación\marcas dientes de dragon\resultados prueba diente dragon\resultados_e_imagenes"
EXCEL_FILENAME = "prueba 17.xlsx"
NET_XML_PATH = r"C:\Users\danie\Desktop\PC\maestría\2do semestre\02.- Modelado y simulación\marcas dientes de dragon\maravatio-zapotlanejo MED-015D\Assets\_Project\Sumo_Data\net.net.xml"

# --- Definición de la ruta principal ---
MAIN_ROUTE_EDGES = [
    '-65', '-65.541', '-69', '-71', '-72', '-73', '-80',
    '-81', '-82', '-82.18', '-83#0'
]

# --- 2. ZONAS DE ANÁLISIS ---
ZONES = {
    "upstream segment": {"x_inicio": 1720.09, "x_fin": 1425.66},
    "treated segment": {"x_inicio": 1425.66, "x_fin": 1140.02},
    "downstream segment": {"x_inicio": 1140.02, "x_fin": 845.72},
}

# --- 3. FUNCIONES ---

def get_edge_lengths(net_xml_path):
    edge_lengths = {}
    if not os.path.exists(net_xml_path):
        print(f"WARNING: Network file not found at '{net_xml_path}'.")
        return None
    try:
        tree = ET.parse(net_xml_path)
        root = tree.getroot()
        for edge in root.findall('edge'):
            edge_id = edge.get('id')
            lane = edge.find('lane')
            if edge_id and lane is not None and 'length' in lane.attrib:
                edge_lengths[edge_id] = float(lane.get('length'))
    except ET.ParseError as e:
        print(f"Error parsing network file {net_xml_path}: {e}")
        return None
    return edge_lengths

def calculate_total_route_length(route_edges, edge_lengths):
    total_length = 0
    if not edge_lengths: return 0
    for edge_id in route_edges:
        length = edge_lengths.get(edge_id)
        if length is not None:
            total_length += length
        else:
            print(f"WARNING: Edge '{edge_id}' not found in network file for total length calculation.")
    return total_length

def parse_fcd_data_for_stats_and_plots(fcd_xml_path):
    debug_msgs, warning_msgs, data_list = [], [], []
    if not os.path.exists(fcd_xml_path):
        warning_msgs.append(f"FCD file not found at: {fcd_xml_path}")
        return None, debug_msgs, warning_msgs
    try:
        tree = ET.parse(fcd_xml_path)
        root = tree.getroot()
        for timestep in root.findall('timestep'):
            time = float(timestep.get('time'))
            for vehicle in timestep.findall('vehicle'):
                if vehicle.get('id') == '0':
                    data_list.append({'time': time, 'x': float(vehicle.get('x')), 'y': float(vehicle.get('y')),'speed': float(vehicle.get('speed')), 'pos': float(vehicle.get('pos')), 'lane': vehicle.get('lane')})
                    break
    except ET.ParseError as e:
        warning_msgs.append(f"Error parsing {fcd_xml_path}: {e}")
        return None, debug_msgs, warning_msgs
    if not data_list:
        warning_msgs.append(f"No data found for vehicle '0' in {fcd_xml_path}.")
        return None, debug_msgs, warning_msgs
    df = pd.DataFrame(data_list)
    df = df.sort_values(by='time').reset_index(drop=True)
    df['acceleration'] = df['speed'].diff() / df['time'].diff()
    df.replace([np.inf, -np.inf], np.nan, inplace=True)
    df.fillna(0, inplace=True)
    return df, debug_msgs, warning_msgs

def get_lane_base_name(lane_id):
    if ':' in lane_id: return None
    if '_' in lane_id: return lane_id.rsplit('_', 1)[0]
    return lane_id

def calculate_statistics(df, zones, edge_lengths, total_route_length, main_route_edges):
    stats = {}
    for zone_name, coords in zones.items():
        zone_df = df[(df['x'] >= coords['x_fin']) & (df['x'] <= coords['x_inicio'])]
        if not zone_df.empty:
            stats[f'Average Speed ({zone_name})'] = zone_df['speed'].mean()
            stats[f'Maximum Speed ({zone_name})'] = zone_df['speed'].max()
            stats[f'Minimum Speed ({zone_name})'] = zone_df['speed'].min()
            if zone_name == "treated segment":
                decelerations = zone_df[zone_df['acceleration'] < 0]['acceleration']
                stats['Average Deceleration (treated segment)'] = (decelerations.mean() * -1) if not decelerations.empty else 0
            if zone_name == "downstream segment":
                accelerations = zone_df[zone_df['acceleration'] > 0]['acceleration']
                stats['Average Acceleration (downstream segment)'] = accelerations.mean() if not accelerations.empty else 0
        else:
            stats[f'Average Speed ({zone_name})'] = 0; stats[f'Maximum Speed ({zone_name})'] = 0; stats[f'Minimum Speed ({zone_name})'] = 0
    if 'Average Deceleration (treated segment)' not in stats: stats['Average Deceleration (treated segment)'] = 0
    if 'Average Acceleration (downstream segment)' not in stats: stats['Average Acceleration (downstream segment)'] = 0

    distance_traveled = 0
    if edge_lengths and not df.empty:
        df['edge'] = df['lane'].apply(get_lane_base_name)
        edge_sequence = df.dropna(subset=['edge']).loc[df['edge'].shift() != df['edge'], 'edge'].tolist()
        for i, edge_id in enumerate(edge_sequence):
            if edge_id in main_route_edges:
                if i < len(edge_sequence) - 1:
                    distance_traveled += edge_lengths.get(edge_id, 0)
                else:
                    last_edge_df = df[df['edge'] == edge_id]
                    if not last_edge_df.empty:
                        distance_traveled += last_edge_df['pos'].max()
    percentage_traveled = 0
    if total_route_length > 0:
        percentage_traveled = (distance_traveled / total_route_length) * 100
    stats['Percentage of Path Traveled'] = min(percentage_traveled, 100.0)

    avg_speed_A = stats.get('Average Speed (upstream segment)', 0)
    avg_speed_PC = stats.get('Average Speed (treated segment)', 0)
    if avg_speed_A > 0:
        stats['Speed Reduction % (upstream -> treated)'] = ((avg_speed_A - avg_speed_PC) / avg_speed_A) * 100
    else:
        stats['Speed Reduction % (upstream -> treated)'] = 0
    return stats

def plot_speed_profile(df, zones, title):
    if df.empty: return None
    start_x = df['x'].max()
    df['distance_traveled'] = start_x - df['x']
    plt.figure(figsize=(12, 6)); plt.plot(df['distance_traveled'], df['speed'] * 3.6, label='Vehicle Speed', color='blue')
    colors = get_cmap('viridis', len(zones)); zone_items = list(zones.items())
    for i, (zone_name, coords) in enumerate(zone_items):
        zone_start_dist = start_x - coords['x_inicio']
        zone_end_dist = start_x - coords['x_fin']
        plt.axvspan(zone_start_dist, zone_end_dist, color=colors(i / len(zone_items)), alpha=0.2, label=zone_name)
    plt.xlabel('Distance Traveled (m)'); plt.ylabel('Speed (km/h)'); plt.title(title)
    plt.legend(); plt.grid(True)
    buf = io.BytesIO(); plt.savefig(buf, format='png', bbox_inches='tight'); plt.close(); buf.seek(0)
    return buf

# --- ### NUEVO: Dos funciones separadas para las gráficas de barras ### ---

def plot_acceleration_chart(results_list, title):
    """Genera una gráfica de barras para la ACELERACIÓN promedio por escenario."""
    scenarios = [res.get('scenario_name', '') for res in results_list]
    accelerations = [res.get('Average Acceleration (downstream segment)', 0) for res in results_list]

    plt.figure(figsize=(8, 5))
    plt.bar(scenarios, accelerations, color='skyblue')

    plt.ylabel('Avg. Acceleration (m/s²)')
    plt.title(title)
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()

    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight')
    plt.close()
    buf.seek(0)
    return buf

def plot_deceleration_chart(results_list, title):
    """Genera una gráfica de barras para la DESACELERACIÓN promedio por escenario."""
    scenarios = [res.get('scenario_name', '') for res in results_list]
    decelerations = [res.get('Average Deceleration (treated segment)', 0) for res in results_list]

    plt.figure(figsize=(8, 5))
    plt.bar(scenarios, decelerations, color='salmon')

    plt.ylabel('Avg. Deceleration (m/s²)')
    plt.title(title)
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()

    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight')
    plt.close()
    buf.seek(0)
    return buf


# --- 4. BLOQUE PRINCIPAL DE EJECUCIÓN ---

if __name__ == "__main__":

    edge_lengths = get_edge_lengths(NET_XML_PATH)
    total_route_length = calculate_total_route_length(MAIN_ROUTE_EDGES, edge_lengths)

    if total_route_length > 0:
        print(f"Total main route length calculated: {total_route_length:.2f} m")
    else:
        print("WARNING: Could not calculate total route length.")

    excel_output_path = os.path.join(OUTPUT_FOLDER, EXCEL_FILENAME)
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    workbook = openpyxl.Workbook()
    if 'Sheet' in workbook.sheetnames: workbook.remove(workbook['Sheet'])

    try:
        participant_folders = [d for d in os.listdir(BASE_RESULTS_FOLDER) if os.path.isdir(os.path.join(BASE_RESULTS_FOLDER, d))]
    except FileNotFoundError:
        print(f"\n[ERROR] Base results folder not found: '{BASE_RESULTS_FOLDER}'"); exit()

    print(f"Processing {len(participant_folders)} participants.")

    for participant_id in participant_folders:
        participant_folder_path = os.path.join(BASE_RESULTS_FOLDER, participant_id)
        print(f"\n{'='*20}\nProcessing participant: {participant_id}\n{'='*20}")

        sheet_name = "".join(c for c in str(participant_id) if c.isalnum())[:31]
        ws = workbook.create_sheet(title=sheet_name)
        ws.cell(row=1, column=1, value="Scenario Analysis for " + participant_id).font = Font(bold=True, size=14)
        current_row = 3

        scenarios = {"dragon teeth": "DD.xml", "transverse bars": "RL.xml", "no marking": "SM.xml"}

        participant_scenario_results = []

        for scenario_name, fcd_filename in scenarios.items():
            fcd_path = os.path.join(participant_folder_path, fcd_filename)
            print(f"\n--- Analyzing scenario: {scenario_name} ---")
            df, debug_msgs, warning_msgs = parse_fcd_data_for_stats_and_plots(fcd_path)
            if warning_msgs:
                for msg in warning_msgs: print(f"  WARNING: {msg}")

            if df is not None and not df.empty:
                statistical_results = calculate_statistics(df, ZONES, edge_lengths, total_route_length, MAIN_ROUTE_EDGES)
                statistical_results['scenario_name'] = scenario_name
                participant_scenario_results.append(statistical_results)

                ws.cell(row=current_row, column=1, value=scenario_name).font = Font(bold=True)
                current_row += 1

                stats_order = [
                    'Percentage of Path Traveled',
                    'Average Speed (upstream segment)', 'Maximum Speed (upstream segment)', 'Minimum Speed (upstream segment)',
                    'Average Speed (treated segment)', 'Maximum Speed (treated segment)', 'Minimum Speed (treated segment)',
                    'Average Deceleration (treated segment)',
                    'Speed Reduction % (upstream -> treated)',
                    'Average Speed (downstream segment)', 'Maximum Speed (downstream segment)', 'Minimum Speed (downstream segment)',
                    'Average Acceleration (downstream segment)'
                ]

                for stat_name in stats_order:
                    if stat_name in statistical_results:
                        stat_value = statistical_results[stat_name]
                        display_value = f"{stat_value:.2f}%" if "Percentage" in stat_name or "%" in stat_name else (f"{stat_value:.2f}" if isinstance(stat_value, (int, float)) else stat_value)
                        ws.cell(row=current_row, column=1, value=stat_name)
                        ws.cell(row=current_row, column=2, value=display_value)
                        current_row += 1

                plot_title = f"Velocity Profile - {participant_id}\n{scenario_name}"
                img_buffer = plot_speed_profile(df, ZONES, plot_title)
                if img_buffer:
                    img = ExcelImage(img_buffer)
                    ws.add_image(img, f'D{current_row - len(stats_order) - 1}')
                current_row += 15
            else:
                print(f"  No data generated or error for {scenario_name}.")
                ws.cell(row=current_row, column=1, value=f"Could not process data for {scenario_name}").font = Font(italic=True)
                current_row += 2

        # --- ### NUEVO: Generar y añadir las dos gráficas de barras separadas ### ---
        if participant_scenario_results:
            # Gráfica de Aceleración
            accel_title = f"Average Acceleration Comparison - {participant_id}"
            accel_buffer = plot_acceleration_chart(participant_scenario_results, accel_title)
            if accel_buffer:
                ws.add_image(ExcelImage(accel_buffer), 'J3')

            # Gráfica de Desaceleración
            decel_title = f"Average Deceleration Comparison - {participant_id}"
            decel_buffer = plot_deceleration_chart(participant_scenario_results, decel_title)
            if decel_buffer:
                ws.add_image(ExcelImage(decel_buffer), 'J28') # Colocarla debajo de la primera

    try:
        workbook.save(excel_output_path)
        print(f"\n--- PROCESS COMPLETE! ---")
        print(f"Excel report saved to: {excel_output_path}")
    except Exception as e:
        print(f"\n[ERROR] Could not save the Excel file. Please ensure it is not open. Detail: {e}")