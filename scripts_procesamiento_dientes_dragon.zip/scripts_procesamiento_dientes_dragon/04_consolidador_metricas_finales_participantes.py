import openpyxl
import pandas as pd
import os

# Ruta al archivo Excel
excel_file_path = r"C:\Users\danie\Desktop\PC\maestría\2do semestre\02.- Modelado y simulación\marcas dientes de dragon\resultados prueba diente dragon\resultados_e_imagenes\data.xlsx"

# Verifica si el archivo existe
if not os.path.exists(excel_file_path):
    print(f"Error: El archivo no se encontró en la ruta especificada: {excel_file_path}")
else:
    try:
        # Carga el libro de trabajo de Excel
        workbook = openpyxl.load_workbook(excel_file_path, data_only=True) # data_only=True para obtener los valores calculados

        # Lista para almacenar los datos de cada participante
        data = []

        # Itera sobre cada hoja (pestaña) en el libro de trabajo
        for sheet_name in workbook.sheetnames:
            sheet = workbook[sheet_name]

            # Intenta obtener los valores de las celdas, maneja el error si la celda no existe
            try:
                escenario_rayado_logaritmico = sheet['B17'].value
            except AttributeError:
                escenario_rayado_logaritmico = None # O puedes asignar un valor por defecto como 'N/A'

            try:
                escenario_diente_de_dragon = sheet['B134'].value
            except AttributeError:
                escenario_diente_de_dragon = None

            try:
                escenario_sin_marca = sheet['B251'].value
            except AttributeError:
                escenario_sin_marca = None

            # Agrega los datos a la lista
            data.append({
                'Número de Participante': sheet_name,
                'Escenario Rayado Logarítmico': escenario_rayado_logaritmico,
                'Escenario Diente de Dragón': escenario_diente_de_dragon,
                'Escenario Sin Marca': escenario_sin_marca
            })

        # Crea un DataFrame de pandas con los datos
        df = pd.DataFrame(data)

        # Guarda el DataFrame en un nuevo archivo Excel
        output_file_path = r"C:\Users\danie\Desktop\PC\maestría\2do semestre\02.- Modelado y simulación\marcas dientes de dragon\resultados prueba diente dragon\resultados_generados.xlsx"
        df.to_excel(output_file_path, index=False)

        print(f"Tabla generada y guardada exitosamente en: {output_file_path}")

    except Exception as e:
        print(f"Ocurrió un error al procesar el archivo Excel: {e}")