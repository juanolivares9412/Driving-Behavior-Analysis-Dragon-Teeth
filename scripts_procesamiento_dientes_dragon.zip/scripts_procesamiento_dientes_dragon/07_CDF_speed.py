import pandas as pd
from scipy.stats import ttest_rel, wilcoxon
from numpy import mean, std
import math
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
file_path = 'Speed_Dataset_Final.csv'
data = pd.read_csv(file_path)

# Cumulative Distribution Function (CDF)
plt.figure(figsize=(10, 5))
# Dragon Teeth
sns.ecdfplot(data['Sm_D_u']*3.6, color='green', linestyle='-', linewidth=2, label='Dragon Teeth (upstream)')
sns.ecdfplot(data['Sm_D_d']*3.6, color='green', linestyle='--', linewidth=2, label='Dragon Teeth (downstream)')
# Transverse Bars
sns.ecdfplot(data['Sm_T_u']*3.6, color='blue', linestyle='-.', linewidth=2, label='Transverse Bars (upstream)')
sns.ecdfplot(data['Sm_T_d']*3.6, color='blue', linestyle=':', linewidth=2, label='Transverse Bars (downstream)')
# No Making
sns.ecdfplot(data['Sm_N_u']*3.6, color='red', linestyle=(0, (5, 5)), linewidth=2, label='No Marking (upstream)')
sns.ecdfplot(data['Sm_N_d']*3.6, color='red', linestyle=(0, (1, 1)), linewidth=2, label='No Marking (downstream)')

# Titles and Labels
plt.title('CDFs')
plt.xlabel('Mean Speed (km/h)')
plt.ylabel('Cumulative Probability')
plt.legend()
plt.grid(True)
plt.xlim(40, 120)  # Set x-axis limits to 40-120 km/h
plt.tight_layout()

# Save in different formats
plt.savefig('CDF_speed.pdf', format='pdf')  # Vector format

# Show plot
plt.show()

