import os
import xml.etree.ElementTree as ET
import csv
import math
import openpyxl
from openpyxl.styles import Font, Alignment
from openpyxl.utils import get_column_letter

# --- 1. CONFIGURACIÓN DE RUTAS Y PARÁMETROS ---
BASE_RESULTS_FOLDER = r"C:\Users\danie\Desktop\PC\maestría\2do semestre\02.- Modelado y simulación\marcas dientes de dragon\resultados prueba diente dragon\participantes cambio de carril"
OUTPUT_FOLDER = r"C:\Users\danie\Desktop\PC\maestría\2do semestre\02.- Modelado y simulación\marcas dientes de dragon\resultados prueba diente dragon\resultados_e_imagenes"
EXCEL_FILENAME = 'prueba 16 cambios de carril.xlsx'

# --- 2. CONFIGURACIÓN DE ZONAS Y ESCENARIOS ---
ZONA_PUNTO_CRITICO = {"x_inicio": 3000, "x_fin": 2700}
GAP_THRESHOLD_METERS = 50.0
SCENARIO_FILES = {
    "Diente de Dragon": "DD.xml",
    "Rayado Logarítmico": "RL.xml",
    "Sin Marca": "SM.xml"
}

# --- 3. FUNCIONES DE ANÁLISIS ---
def get_lane_index(lane_id):
    if '_' in lane_id:
        try: return int(lane_id.rsplit('_', 1)[-1])
        except (ValueError, IndexError): return -1
    return -1

def get_lane_base_name(lane_id):
    if '_' in lane_id:
        return lane_id.rsplit('_', 1)[0]
    return lane_id

def find_true_lane_changes_in_zone(file_path, zone):
    """
    Detecta cambios de carril reales (dentro del mismo tramo) y vacíos,
    interpretando los vacíos como un cambio de Izquierda a Derecha.
    """
    change_events = []
    vehicle_data = []
    if not os.path.exists(file_path): return []
    try:
        tree = ET.parse(file_path)
        root = tree.getroot()
        for timestep in root.findall('timestep'):
            time = float(timestep.get('time'))
            for vehicle in timestep.findall('vehicle'):
                if vehicle.get('id') == '0':
                    vehicle_data.append({'time': time, 'x': float(vehicle.get('x')), 'y': float(vehicle.get('y')), 'lane': vehicle.get('lane')})
                    break
    except ET.ParseError: return []

    vehicle_data.sort(key=lambda d: d['time'])
    if len(vehicle_data) < 2: return []

    for i in range(1, len(vehicle_data)):
        previous_point, current_point = vehicle_data[i-1], vehicle_data[i]
        event_to_add = None
        distance_gap = math.sqrt((current_point['x'] - previous_point['x'])**2 + (current_point['y'] - previous_point['y'])**2)
        x_coord, y_coord = current_point['x'], current_point['y']

        # 1. Prioridad 1: Detectar un vacío e interpretarlo.
        if distance_gap > GAP_THRESHOLD_METERS:
            if zone['x_fin'] <= x_coord <= zone['x_inicio']:
                # Aplicar la lógica de inferencia: un vacío es un cambio I -> D
                event_to_add = {"x_pos": x_coord, "y_pos": y_coord, "direccion": "Implícito (Izq > Der)", "tipo_evento": "Vacío"}

        # 2. Si no hubo vacío, buscar un cambio explícito real.
        elif current_point['lane'] != previous_point['lane']:
            prev_base_name = get_lane_base_name(previous_point['lane'])
            curr_base_name = get_lane_base_name(current_point['lane'])

            if prev_base_name == curr_base_name: # Solo contar si es en el mismo tramo
                if zone['x_fin'] <= x_coord <= zone['x_inicio']:
                    direccion = "Izquierda a Derecha" if get_lane_index(current_point['lane']) < get_lane_index(previous_point['lane']) else "Derecha a Izquierda"
                    event_to_add = {"x_pos": x_coord, "y_pos": y_coord, "direccion": direccion, "tipo_evento": "Explícito"}

        if event_to_add:
            change_events.append(event_to_add)
    return change_events

# --- 4. BLOQUE PRINCIPAL DE EJECUCIÓN ---
if __name__ == "__main__":
    print(f"--- INICIANDO ANÁLISIS FINAL CON INFERENCIA DE VACÍOS ---")
    print(f"Zona de análisis: X = {ZONA_PUNTO_CRITICO['x_inicio']} a {ZONA_PUNTO_CRITICO['x_fin']}")

    excel_output_path = os.path.join(OUTPUT_FOLDER, EXCEL_FILENAME)
    workbook = openpyxl.Workbook()

    consolidado_sheet = workbook.active
    consolidado_sheet.title = "Consolidado"
    headers_consolidado = ['participante_id', 'escenario', 'x_pos_evento', 'y_pos_evento', 'distancia_desde_inicio_zona_m', 'tipo_evento', 'direccion']
    consolidado_sheet.append(headers_consolidado)
    for cell in consolidado_sheet[1]:
        cell.font = Font(bold=True)

    try:
        participant_folders = [d for d in os.listdir(BASE_RESULTS_FOLDER) if os.path.isdir(os.path.join(BASE_RESULTS_FOLDER, d))]
    except FileNotFoundError:
        print(f"\n[ERROR] La ruta base no fue encontrada: '{BASE_RESULTS_FOLDER}'")
        exit()

    for participant_id in participant_folders:
        participant_path = os.path.join(BASE_RESULTS_FOLDER, participant_id)
        print(f"\n--- Procesando participante: {participant_id} ---")

        sheet_name = "".join(c for c in str(participant_id) if c.isalnum())[:31]
        participant_sheet = workbook.create_sheet(title=sheet_name)
        headers_participante = ["Escenario", "Cambios (Izquierda a Derecha)", "Cambios (Derecha a Izquierda)"]
        participant_sheet.append(headers_participante)
        for cell in participant_sheet[1]:
            cell.font = Font(bold=True)
            cell.alignment = Alignment(horizontal='center')

        for row_num, (scenario_name, xml_filename) in enumerate(SCENARIO_FILES.items(), start=2):
            file_path = os.path.join(participant_path, xml_filename)
            events_in_zone = find_true_lane_changes_in_zone(file_path, ZONA_PUNTO_CRITICO)

            if events_in_zone:
                print(f"  -> Se detectaron {len(events_in_zone)} eventos en '{xml_filename}'.")
                for event in events_in_zone:
                    distancia_desde_inicio = ZONA_PUNTO_CRITICO['x_inicio'] - event['x_pos']
                    row_data = [
                        participant_id, scenario_name,
                        round(event['x_pos'], 2), round(event['y_pos'], 2),
                        round(distancia_desde_inicio, 2),
                        event['tipo_evento'], event['direccion']
                    ]
                    consolidado_sheet.append(row_data)

            # --- ### LÓGICA DE CONTEO ACTUALIZADA ### ---
            # Se cuentan los explícitos I->D y los implícitos (que también son I->D)
            count_ID = sum(1 for e in events_in_zone if e['direccion'] == 'Izquierda a Derecha' or e['direccion'] == 'Implícito (Izq > Der)')
            # Se cuentan solo los explícitos D->I
            count_DI = sum(1 for e in events_in_zone if e['direccion'] == 'Derecha a Izquierda')

            participant_sheet.cell(row=row_num, column=1, value=scenario_name)
            participant_sheet.cell(row=row_num, column=2, value=count_ID)
            participant_sheet.cell(row=row_num, column=3, value=count_DI)

        for col_idx, header in enumerate(headers_participante, 1):
            participant_sheet.column_dimensions[get_column_letter(col_idx)].width = len(header) + 5

    for col_idx, header in enumerate(headers_consolidado, 1):
        consolidado_sheet.column_dimensions[get_column_letter(col_idx)].width = len(header) + 5

    try:
        workbook.save(excel_output_path)
        print(f"\n--- ¡Proceso completado! ---")
        print(f"Reporte final con inferencia de vacíos guardado en: {excel_output_path}")
    except Exception as e:
        print(f"\n[ERROR] No se pudo guardar el archivo Excel. Causa: {e}")