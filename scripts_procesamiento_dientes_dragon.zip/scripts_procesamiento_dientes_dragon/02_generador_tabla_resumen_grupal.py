import pandas as pd
import openpyxl
import os

# --- 1. CONFIGURACIÓN DE RUTAS ---
# Ruta donde se encuentra el reporte generado por el script anterior
INPUT_FOLDER = r"C:\Users\danie\Desktop\PC\maestría\2do semestre\02.- Modelado y simulación\marcas dientes de dragon\resultados prueba diente dragon\resultados_e_imagenes"

# Nombre del archivo de Excel con una pestaña por participante que se va a leer
INPUT_FILENAME = "prueba 17.xlsx" # Asegúrate que este sea el nombre correcto

# Nombre del nuevo archivo de Excel con la tabla agrupada
OUTPUT_FILENAME = "prueba 17 tabla resumen para articulo.xlsx"

# --- 2. LÓGICA DEL SCRIPT ---

def create_grouped_report(input_path, output_path):
    """
    Lee un archivo de Excel con datos por pestaña y crea una única tabla
    agrupada por escenario, donde cada fila es un participante.
    """
    if not os.path.exists(input_path):
        print(f"Error: El archivo de entrada no fue encontrado en: {input_path}")
        return

    try:
        workbook = openpyxl.load_workbook(input_path, data_only=True)
    except Exception as e:
        print(f"Error al abrir el archivo de Excel: {e}")
        return

    all_data_records = []

    # PASO 1: Extraer los datos en un formato largo (igual que antes)
    for sheet_name in workbook.sheetnames:
        sheet = workbook[sheet_name]
        participant_id = sheet_name
        print(f"Leyendo datos del participante: {participant_id}...")

        current_scenario = None
        scenario_data = {}

        for row in sheet.iter_rows(values_only=True):
            if not row or len(row) < 2:
                continue

            if row[0] and row[1] is None:
                if current_scenario and scenario_data:
                    scenario_data['Participant ID'] = participant_id
                    scenario_data['Scenario'] = current_scenario
                    all_data_records.append(scenario_data)
                current_scenario = row[0]
                scenario_data = {}
            elif row[0] and row[1] is not None:
                metric_name = str(row[0]).strip()
                metric_value = row[1]
                if isinstance(metric_value, str) and '%' in metric_value:
                    try:
                        metric_value = float(metric_value.replace('%', ''))
                    except (ValueError, TypeError):
                        pass
                scenario_data[metric_name] = metric_value

        if current_scenario and scenario_data:
            scenario_data['Participant ID'] = participant_id
            scenario_data['Scenario'] = current_scenario
            all_data_records.append(scenario_data)

    if not all_data_records:
        print("No se encontraron datos para procesar.")
        return

    df_long = pd.DataFrame(all_data_records)

    # --- ### CORRECCIÓN: Usar un método de reorganización más robusto ### ---
    print("\nReorganizando la tabla en el formato agrupado...")
    try:
        # PASO 2: Transformar la tabla a un formato "largo" ideal para pivotar
        id_vars = ['Participant ID', 'Scenario']
        value_vars = [col for col in df_long.columns if col not in id_vars]
        df_melted = df_long.melt(
            id_vars=id_vars,
            value_vars=value_vars,
            var_name='Metric',
            value_name='Value'
        )

        # PASO 3: Pivotar la tabla usando 'first' para evitar errores con texto
        df_pivot = df_melted.pivot_table(
            index='Participant ID',
            columns=['Scenario', 'Metric'],
            values='Value',
            aggfunc='first' # <-- Esta es la clave: solo toma el primer valor, no calcula nada.
        )

        # Opcional: Ordenar las columnas para asegurar una estructura consistente
        df_pivot.sort_index(axis=1, level='Scenario', inplace=True)

    except Exception as e:
        print(f"Error al reorganizar la tabla. Causa probable: {e}")
        return

    # PASO 4: Guardar el nuevo DataFrame en un archivo de Excel
    try:
        df_pivot.to_excel(output_path, index=True)
        print("\n--- ¡PROCESO COMPLETADO! ---")
        print(f"Tabla agrupada guardada exitosamente en:")
        print(output_path)
    except Exception as e:
        print(f"\nError al guardar el nuevo archivo de Excel: {e}")
        print("Asegúrate de que el archivo no esté abierto.")

# --- 3. BLOQUE PRINCIPAL DE EJECUCIÓN ---
if __name__ == "__main__":
    input_excel_path = os.path.join(INPUT_FOLDER, INPUT_FILENAME)
    output_excel_path = os.path.join(INPUT_FOLDER, OUTPUT_FILENAME)

    create_grouped_report(input_excel_path, output_excel_path)