import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os

# --- 1. Global Style Configuration (To match your PDFs) ---
try:
    plt.rcParams.update({
        'font.family': 'serif',
        'font.serif': 'Times New Roman',
        'font.size': 12,
        'axes.labelsize': 12,
        'xtick.labelsize': 10,
        'ytick.labelsize': 10,
        'axes.grid': True,
        'grid.color': '#cccccc',
        'grid.linestyle': '--',
        'grid.linewidth': 0.5,
        'xtick.direction': 'in',
        'ytick.direction': 'in',
        'legend.fontsize': 10,
        'figure.dpi': 150
    })
except Exception as e:
    print(f"Warning: Could not load 'Times New Roman' font. Using default serif. Error: {e}")

# --- 2. Data Loading ---
file_path = r"C:\Users\danie\Desktop\PC\maestría\articulo 01.- Simulador para la evaluación de marca diente dragon\imagenes\cuestionario.xlsx"
output_dir = os.path.dirname(file_path)

try:
    # Skip row 1 (index 1) which contains the "Hoja de Códigos" notes
    df = pd.read_excel(file_path, sheet_name='Hoja2', skiprows=[1])

    print(f"Excel file '{os.path.basename(file_path)}' loaded successfully.")
    print("First rows of data (without 'Notes' row):")
    print(df.head())
except Exception as e:
    print(f"Fatal error reading Excel file at: {file_path}")
    print(f"Error detail: {e}")
    print("Please check if the path is correct and the sheet is named 'Hoja2'.")
    exit()

# --- 3. Styled Plotting Functions ---

def graficar_barras(data_series, title, xlabel, save_name, custom_labels=None, colors=None):
    """
    Generates a bar chart with percentage labels and all categories (even 0-count).
    """
    print(f"Generating bar chart: {title}")
    if colors is None:
        colors = ['#0000FF', '#008000', '#FF0000', '#808080', '#555555']

    data_series_numeric = pd.to_numeric(data_series, errors='coerce')
    counts = data_series_numeric.value_counts()

    # Reindex to include all categories (even with 0 votes)
    if custom_labels:
        all_categories = list(custom_labels.keys())
        counts = counts.reindex(all_categories, fill_value=0)

    counts = counts.sort_index()

    # Get total responses for THIS question to calculate percentage
    total_responses = data_series_numeric.dropna().count()

    # Apply friendly labels AFTER reindexing
    if custom_labels:
        counts.index = counts.index.map(custom_labels)

    plt.figure(figsize=(7, 5))

    ax = counts.plot(kind='bar', color=colors[:len(counts)], edgecolor='black', zorder=3)

    # Add percentage labels on top of bars
    if total_responses > 0: # Avoid division by zero
        for p in ax.patches:
            height = p.get_height()
            percentage = 100 * height / total_responses
            ax.annotate(f'{percentage:.0f}%', # Format as integer percentage
                        (p.get_x() + p.get_width() / 2., height),
                        ha='center',
                        va='center',
                        xytext=(0, 5), # 5 points vertical offset
                        textcoords='offset points',
                        fontsize=9,
                        color='black')

    # Adjust y-limit to make space for labels
    current_ylim = ax.get_ylim()
    ax.set_ylim(top=current_ylim[1] * 1.15) # Add 15% space at the top

    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel('Number of Participants')
    ax.set_xticklabels(ax.get_xticklabels(), rotation=0)
    ax.grid(True, axis='y', zorder=0)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f"{save_name}.png"))
    plt.show()

def graficar_boxplot_estilizado(data, column, title, ylabel):
    """
    Generates a boxplot with your example's style (red median, '+' outliers).
    """
    print(f"Generating boxplot: {title}")

    data_numeric = pd.to_numeric(data[column], errors='coerce').dropna()

    if data_numeric.empty:
        print(f"Warning: No numeric data for boxplot of '{column}'. Skipping plot.")
        return

    plt.figure(figsize=(4, 6))

    boxplot_props = {
        'patch_artist': True,
        'boxprops': {'facecolor': 'white', 'edgecolor': 'black'},
        'medianprops': {'color': 'red', 'linewidth': 2.5},
        'whiskerprops': {'color': 'black'},
        'capprops': {'color': 'black'},
        'flierprops': {'marker': '+', 'markeredgecolor': 'black', 'markersize': 8}
    }

    plt.boxplot(data_numeric, **boxplot_props)

    plt.title(title)
    plt.ylabel(ylabel)
    # Use column name for x-tick, split for simplicity
    x_label = column.split('_')[-1]
    if x_label.lower() == 'experiencia': x_label = 'Experience' # Translate
    plt.xticks([1], [x_label])
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f"boxplot_{column}.png"))
    plt.show()

# --- *** NUEVA FUNCIÓN AÑADIDA *** ---
def graficar_boxplot_comparativo_genero(data, num_col, title, ylabel):
    """
    Generates a side-by-side boxplot for Age comparing Male (1) and Female (2).
    """
    print(f"Generating comparative boxplot: {title}")

    # Specific filter for this request (Male=1, Female=2)
    male_ages = pd.to_numeric(data[data['S1_P2_Genero'] == 1][num_col], errors='coerce').dropna()
    female_ages = pd.to_numeric(data[data['S1_P2_Genero'] == 2][num_col], errors='coerce').dropna()

    data_to_plot = []
    labels_to_use = []

    # Only add data if it exists
    if not male_ages.empty:
        data_to_plot.append(male_ages)
        labels_to_use.append('Male')
    if not female_ages.empty:
        data_to_plot.append(female_ages)
        labels_to_use.append('Female')

    if not data_to_plot:
        print(f"Warning: No data for comparative age/gender boxplot.")
        return

    plt.figure(figsize=(6, 6))

    # Re-use the same style props
    boxplot_props = {
        'patch_artist': True, 'boxprops': {'facecolor': 'white', 'edgecolor': 'black'},
        'medianprops': {'color': 'red', 'linewidth': 2.5},
        'whiskerprops': {'color': 'black'}, 'capprops': {'color': 'black'},
        'flierprops': {'marker': '+', 'markeredgecolor': 'black', 'markersize': 8}
    }

    plt.boxplot(data_to_plot, **boxplot_props)

    plt.title(title)
    plt.ylabel(ylabel)
    plt.xticks(range(1, len(labels_to_use) + 1), labels_to_use)
    plt.xlabel('Gender')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f"boxplot_compare_Age_by_Gender.png"))
    plt.show()
# --- *** FIN DE NUEVA FUNCIÓN *** ---

def graficar_cdf_estilizada(data, column, title, xlabel):
    """
    Generates a CDF plot with your example's style (solid blue line).
    """
    print(f"Generating CDF: {title}")

    data_clean = pd.to_numeric(data[column], errors='coerce').dropna().sort_values()

    if data_clean.empty:
        print(f"Warning: No numeric data for CDF of '{column}'. Skipping plot.")
        return

    yvals = np.arange(1, len(data_clean) + 1) / len(data_clean)

    plt.figure(figsize=(7, 5))
    plt.plot(data_clean, yvals, 'b-', label='Distribution', linewidth=2)

    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel('CDF (Cumulative Probability)')
    plt.legend(loc='best')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f"cdf_{column}.png"))
    plt.show()

# --- 4. Plotting Execution ---
if 'df' in locals():

    # Get total number of participants for multi-choice percentages
    total_participants = len(df)

    # --- Section 2 Plots: Simulator Perception ---

    # P8. Realism (Bar chart as requested)
    labels_realismo = {
        1: '1 (Not at all)',
        2: '2',
        3: '3 (Neutral)',
        4: '4',
        5: '5 (Very realistic)'
    }
    if 'S2_P8_Realismo' in df.columns:
        graficar_barras(df['S2_P8_Realismo'],
                        'Simulator Realism Rating',
                        'Perceived Rating (1=Not at all, 5=Very realistic)',
                        'bar_S2_P8_Realism',
                        custom_labels=labels_realismo)
    else:
        print("Warning: Column 'S2_P8_Realismo' not found.")

    # P9. Difficulty adapting
    labels_dificultad = {
        1: 'None',
        2: 'Mild',
        3: 'Moderate',
        4: 'Strong'
    }
    if 'S2_P9_Dificultad' in df.columns:
        graficar_barras(df['S2_P9_Dificultad'],
                        'Difficulty Adapting to the Simulator',
                        'Difficulty Level',
                        'bar_S2_P9_Difficulty',
                        custom_labels=labels_dificultad)
    else:
        print("Warning: Column 'S2_P9_Dificultad' not found.")

    # --- Section 3 Plots: Road Marking Perception ---

    labels_sino = {0: 'No', 1: 'Yes'}

    # P11. Noticed change in markings
    if 'S3_P11_NotoCambio' in df.columns:
        graficar_barras(df['S3_P11_NotoCambio'],
                        'Did you notice any change in the road markings?',
                        'Response',
                        'bar_S3_P11_NoticedChange',
                        custom_labels=labels_sino)
    else:
        print("Warning: Column 'S3_P11_NotoCambio' not found.")

    # P12. Saw "Dragon Teeth"
    if 'S3_P12_VioDientes' in df.columns:
        graficar_barras(df['S3_P12_VioDientes'],
                        'Do you recall seeing the "Dragon Teeth" markings?',
                        'Response',
                        'bar_S3_P12_SawDragonTeeth',
                        custom_labels=labels_sino)
    else:
        print("Warning: Column 'S3_P12_VioDientes' not found.")

    # P12b. Impression caused (Multiple choice)
    print("Generating bar chart: Impression upon seeing markings (P12b)")

    impresion_cols = {
        'S3_P12b_Impresion_Alerta': 'Increased Alertness',
        'S3_P12b_Impresion_Curiosidad': 'Curiosity',
        'S3_P1Vertical_Impresion_Distraccion': 'Distraction'
    }

    cols_existentes = {col: label for col, label in impresion_cols.items() if col in df.columns}

    if cols_existentes and total_participants > 0:
        impresion_counts = df[cols_existentes.keys()].sum()
        impresion_counts.index = impresion_counts.index.map(cols_existentes)

        plt.figure(figsize=(7, 5))
        colors = ['#0000FF', '#008000', '#FF0000']
        ax = impresion_counts.plot(kind='bar', color=colors[:len(impresion_counts)], edgecolor='black', zorder=3)

        # Add percentage labels (based on TOTAL participants)
        for p in ax.patches:
            height = p.get_height()
            percentage = 100 * height / total_participants # Pct of all participants
            ax.annotate(f'{percentage:.0f}%',
                        (p.get_x() + p.get_width() / 2., height),
                        ha='center',
                        va='center',
                        xytext=(0, 5),
                        textcoords='offset points',
                        fontsize=9,
                        color='black')

        current_ylim = ax.get_ylim()
        ax.set_ylim(top=current_ylim[1] * 1.15) # Add 15% space

        ax.set_title('Impression caused by "Dragon Teeth" markings (P12b)')
        ax.set_xlabel('Reported Impression')
        ax.set_ylabel('Number of Participants')
        ax.set_xticklabels(ax.get_xticklabels(), rotation=0)
        ax.grid(True, axis='y', zorder=0)
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, "bar_S3_P12b_Impressions.png"))
        plt.show()
    else:
        print("Warning: 'S3_P12b_Impresion_...' columns not found or no participants.")


    # P13. Felt need to reduce speed
    if 'S3_P13_RedujoVelocidad' in df.columns:
        graficar_barras(df['S3_P13_RedujoVelocidad'],
                        'Did you feel the need to reduce speed? (P13)',
                        'Response',
                        'bar_S3_P13_FeltNeedToSlow',
                        custom_labels=labels_sino)
    else:
        print("Warning: Column 'S3_P13_RedujoVelocidad' not found.")

    # P14. Effectiveness
    labels_efectividad = {
        1: 'Less Effective',
        2: 'Equally Effective',
        3: 'More Effective',
        4: 'No Opinion'
    }
    if 'S3_P14_Efectividad' in df.columns:
        graficar_barras(df['S3_P14_Efectividad'],
                        'Perceived Effectiveness (Dragon Teeth vs Others) (P14)',
                        'Response',
                        'bar_S3_P14_Effectiveness',
                        custom_labels=labels_efectividad)
    else:
        print("Warning: Column 'S3_P14_Efectividad' not found.")

    # P15. Improves Safety
    labels_seguridad = {
        0: 'No',
        1: 'Yes',
        2: 'Not sure'
    }
    # Corregí el typo 'S3_P1S_...' a 'S3_P15_...' que estaba en tu código
    if 'S3_P15_MejoraSeguridad' in df.columns:
        graficar_barras(df['S3_P15_MejoraSeguridad'],
                        'Do you think they improve highway safety? (P15)',
                        'Response',
                        'bar_S3_P15_ImprovesSafety',
                        custom_labels=labels_seguridad)
    else:
        print("Warning: Column 'S3_P15_MejoraSeguridad' not found.")


    # --- Section 1 Plots: Driver Profile ---

    # --- *** BLOQUE DE EDAD REEMPLAZADO *** ---
    # NUEVA GRÁFICA 1: Rangos de Edad (Barras)
    print("Generating bar chart: Age Ranges")
    # Define bins and labels (18-25, 26-35, 36-45, 46+)
    age_bins = [17, 25, 35, 45, np.inf]
    age_labels = {1: '18-25', 2: '26-35', 3: '36-45', 4: '46+'}

    if 'S1_P1_Edad' in df.columns:
        # Crea una nueva serie con los datos agrupados
        # Usamos códigos (1,2,3,4) para que 'graficar_barras' los ordene
        age_binned_series = pd.cut(df['S1_P1_Edad'], bins=age_bins, labels=list(age_labels.keys()), right=True)

        graficar_barras(age_binned_series,
                        'Participant Age Distribution by Range',
                        'Age Range (years)',
                        'bar_S1_P1_AgeRanges',
                        custom_labels=age_labels)
    else:
        print("Warning: Column 'S1_P1_Edad' not found for age range chart.")

    # NUEVA GRÁFICA 2: Edad por Género (Boxplot Comparativo)
    if 'S1_P1_Edad' in df.columns and 'S1_P2_Genero' in df.columns:
        graficar_boxplot_comparativo_genero(df,
                                            num_col='S1_P1_Edad',
                                            title='Age Distribution by Gender',
                                            ylabel='Age (years)')
    else:
        print("Warning: 'S1_P1_Edad' or 'S1_P2_Genero' not found for comparative boxplot.")
    # --- *** FIN DEL BLOQUE REEMPLAZADO *** ---


    # P4. Experience (Boxplot as requested)
    if 'S1_P4_Experiencia' in df.columns:
        graficar_boxplot_estilizado(df,
                                'S1_P4_Experiencia',
                                'Participant Driving Experience', # Title
                                'Years of Experience') # Y-label
    else:
        print("Warning: Column 'S1_P4_Experiencia' not found.")

    # P2. Gender (Esta gráfica sigue aquí, como la añadimos antes)
    labels_genero = {
        1: 'Male',
        2: 'Female',
        3: 'Other'
    }
    if 'S1_P2_Genero' in df.columns:
        graficar_barras(df['S1_P2_Genero'],
                        'Participant Gender Distribution',
                        'Gender',
                        'bar_S1_P2_Gender',
                        custom_labels=labels_genero)
    else:
        print("Warning: Column 'S1_P2_Genero' not found.")
    # --- *** FIN DEL BLOQUE AÑADIDO *** ---

    print("\n--- Analysis complete. Graphs saved in: ---")
    print(output_dir)

else:
    print("Data was not loaded. Cannot generate graphs.")